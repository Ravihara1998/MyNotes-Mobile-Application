package com.example.mynote;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private EditText editTextNote;
    private Button buttonAdd;
    private Button buttonShowNotes;
    private Button buttonDeleteNotes;
    private Button buttonEditNotes;
    private RecyclerView recyclerViewNotes;
    private List<Note> noteList;
    private NoteAdapter noteAdapter;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        editTextNote = findViewById(R.id.editTextNote);
        buttonAdd = findViewById(R.id.buttonAdd);
        buttonShowNotes = findViewById(R.id.buttonShowNotes);
        buttonDeleteNotes = findViewById(R.id.buttonDeleteNotes);
        buttonEditNotes = findViewById(R.id.buttonEditNotes);
        recyclerViewNotes = findViewById(R.id.recyclerViewNotes);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Set up RecyclerView
        noteList = new ArrayList<>();
        noteAdapter = new NoteAdapter(noteList);
        recyclerViewNotes.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewNotes.setAdapter(noteAdapter);

        // Button click listener for adding a note
        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String noteContent = editTextNote.getText().toString();
                if (!noteContent.isEmpty()) {
                    addNoteToDatabase(noteContent);
                    editTextNote.setText("");
                }
            }
        });

        // Button click listener for showing notes
        buttonShowNotes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadNotesFromDatabase();
            }
        });

        // Button click listener for deleting notes
        buttonDeleteNotes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteAllNotesFromDatabase();
                noteList.clear();
                noteAdapter.notifyDataSetChanged();
            }
        });

        // Button click listener for editing notes
        buttonEditNotes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, NoteAdapter.class);
                startActivity(intent);
            }
        });
    }

    private void addNoteToDatabase(String content) {
        long id = databaseHelper.insertNoteContent(content);
        Note note = new Note(id, content);
        noteList.add(note);
        noteAdapter.notifyDataSetChanged();
    }

    private void loadNotesFromDatabase() {
        noteList.clear();
        noteList.addAll(databaseHelper.getAllNotes());
        noteAdapter.notifyDataSetChanged();
    }

    private void deleteAllNotesFromDatabase() {
        databaseHelper.deleteAllNotes();
    }
}
